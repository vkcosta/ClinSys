package DAO;
import java.util.List;
/**
 *
 * @author Mateus Garcia
 */
public interface DAO {
    public void add(Object o);
    public void update(Object o);
    public List getall();
}
